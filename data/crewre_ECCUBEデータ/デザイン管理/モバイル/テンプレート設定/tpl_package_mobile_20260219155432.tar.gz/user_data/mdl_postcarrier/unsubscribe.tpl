<!--{*
/*
 * This file is part of PostCarrier for EC-CUBE
 *
 * Copyright(c) 2010-2017 IPLOGIC CO.,LTD. All Rights Reserved.
 *
 * http://www.iplogic.co.jp/
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
*}-->
<form name="postcarrier_mailcustomer_stop_form" method="post" action="<!--{$smarty.server.PHP_SELF|escape}-->">
<input type="hidden" name="mode" value="stop">
<font color="#FF0000">*は必須項目です。</font><br>
<br>
●メールアドレス<font color="#FF0000"> *</font><br>
<input type="text" name="email" istyle="3"><br>
<input type="submit" value="メルマガ配信停止">
</form>
